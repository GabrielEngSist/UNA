package br.com.meupesoideal;

import br.com.meupesoideal.dto.Pessoa;
import br.com.meupesoideal.dto.ResultadoImc;
import br.com.meupesoideal.enums.Situacao;
import br.com.meupesoideal.interfaces.ICalculadoraImc;

public class CalculadoraImcHomem implements ICalculadoraImc {
    private Pessoa pessoa;
    public CalculadoraImcHomem(Pessoa pessoa){
        this.pessoa = pessoa;
    }
    @Override
    public ResultadoImc calcularImc() {
        float imc = Math.round(pessoa.getPeso() / (float)(Math.pow(pessoa.getAltura(),2)));
        String imagem;
        Situacao situacao;
        if (imc < 20.7) {
            situacao = Situacao.ABAIXO_PESO;
            imagem = "@drawable/homem_abaixo_peso";
        } else if (imc < 26.4) {
            situacao = Situacao.PESO_NORMAL;
            imagem = "@drawable/homem_peso_normal";
        } else if (imc < 31.1) {
            situacao = Situacao.ACIMA_PESO;
            imagem = "@drawable/homem_acima_peso";
        } else {
            situacao = Situacao.OBESO;
            imagem = "@drawable/homem_obeso";
        }
        return new ResultadoImc(situacao, imagem, imc);
    }
}
