package br.com.meupesoideal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import br.com.meupesoideal.dto.Pessoa;
import br.com.meupesoideal.dto.ResultadoImc;

public class CalculadoraPeso extends AppCompatActivity {
    String nome;
    private boolean masculino, isValid;
    EditText etxPeso, etxAltura;
    TextView txtResultado;
    Button btnCalcular;
    TextView txtBoasVindas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initializeProperties();

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate();
                if (isValid) {
                    String uri;
                    Pessoa pessoa = new Pessoa(
                            nome,
                            Integer.parseInt(etxPeso.getText().toString()),
                            Float.parseFloat(etxAltura.getText().toString()),
                            masculino
                    );
                    ResultadoImc resultadoImc = new CalculadoraImcFactory().getCalculadora(pessoa).calcularImc();
                    setImage(resultadoImc);
                    setMessage(resultadoImc);
                }


            }
        });
    }

    private void setMessage(ResultadoImc resultadoImc) {
        String mensagem;
        switch (resultadoImc.getSituacao()) {
            case OBESO:
                mensagem = "Obeso";
                break;
            case ACIMA_PESO:
                mensagem = "Acima do peso";
                break;
            case ABAIXO_PESO:
                mensagem = "Abaixo do peso";
                break;
            case PESO_NORMAL:
                mensagem = "Peso normal";
                break;
            default:
                mensagem = "Não definido";
        }
        txtResultado.setText("Seu IMC é de \n" +String.valueOf(resultadoImc.getImc()) +"\n" + mensagem );
    }

    private void setImage(ResultadoImc resultadoImc) {
        int image = getResources().getIdentifier(resultadoImc.getImagem(), ".png", getPackageName());

        ImageView imageView = (ImageView) findViewById(R.id.imvImc);
        Drawable res = getResources().getDrawable(image);
        imageView.setImageDrawable(res);
        imageView.setVisibility(View.VISIBLE);
    }

    private void initializeProperties() {
        setContentView(R.layout.activity_calculadora_peso);
        etxPeso = findViewById(R.id.etxPeso);
        etxAltura = findViewById(R.id.etxAltura);
        txtResultado = findViewById(R.id.txtResultado);
        btnCalcular = findViewById(R.id.btnCalcular);
        txtBoasVindas = findViewById(R.id.txtBoasVindas);
        setIntentedValues();
    }

    private void setIntentedValues() {
        Intent intent = getIntent();
        ((ImageView) findViewById(R.id.imvImc)).setVisibility(View.INVISIBLE);
        nome = intent.getStringExtra("nome");
        txtBoasVindas.setText("Olá " + nome + "!");
        masculino = intent.getBooleanExtra("masculino", true);
    }

    private void validate() {
        isValid = true;
        if (etxPeso.getText().toString().isEmpty()) {
            etxPeso.setError("Peso é obrigatório");
            isValid = false;
        }
        if (etxAltura.getText().toString().isEmpty()) {
            etxAltura.setError("Altura é obrigatória");
            isValid = false;
        }
    }
}