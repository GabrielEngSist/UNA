package br.com.meupesoideal.dto;

public class Pessoa {
    private String nome;
    private float peso;
    private float altura;
    private boolean masculino;

    public Pessoa(String nome, float peso, float altura, boolean masculino) {
        this.nome = nome;
        this.peso = peso;
        this.altura = altura;
        this.masculino = masculino;
    }

    public boolean isMasculino() {
        return masculino;
    }

    public float getAltura() {
        return altura;
    }

    public float getPeso() {
        return peso;
    }

    public String getNome() {
        return nome;
    }
}
