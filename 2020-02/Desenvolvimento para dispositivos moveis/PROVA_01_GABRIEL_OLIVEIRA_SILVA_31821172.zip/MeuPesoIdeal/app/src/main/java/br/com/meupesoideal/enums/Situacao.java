package br.com.meupesoideal.enums;

public enum Situacao {
  OBESO, ACIMA_PESO, ABAIXO_PESO, PESO_NORMAL
}
