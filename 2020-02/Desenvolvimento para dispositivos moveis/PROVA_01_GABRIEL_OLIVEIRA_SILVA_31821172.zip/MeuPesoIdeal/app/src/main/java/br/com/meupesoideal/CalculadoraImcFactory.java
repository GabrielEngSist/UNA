package br.com.meupesoideal;

import br.com.meupesoideal.dto.Pessoa;
import br.com.meupesoideal.interfaces.ICalculadoraImc;
import br.com.meupesoideal.interfaces.ICalculadoraImcFactory;

public class CalculadoraImcFactory implements ICalculadoraImcFactory {

    @Override
    public ICalculadoraImc getCalculadora(Pessoa pessoa) {
        if(pessoa.isMasculino()){
            return new CalculadoraImcHomem(pessoa);
        }

        return new CalculadoraImcMulher(pessoa);
    }
}
