package br.com.meupesoideal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private boolean isValid = true;
    private Button btnIniciar;
    private EditText etxNome;
    private RadioButton rdbSexoMasculino;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ((TextView)findViewById(R.id.txtAluno)).setText("Gabriel Oliveira Silva");
        etxNome = findViewById(R.id.etxNome);
        btnIniciar = findViewById(R.id.btnIniciar);
        rdbSexoMasculino = findViewById(R.id.rdbSexoMasculino);
        rdbSexoMasculino.setChecked(true);

        btnIniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate();
                goToNextActivity();
            }
        });
    }

    private void validate() {
        isValid = true;
        if (etxNome.getText().toString().isEmpty()) {
            etxNome.setError("Nome não preenchido");
            isValid = false;
        }
    }

    private void goToNextActivity() {
        if (isValid) {
            Intent intent = new Intent(
                    MainActivity.this,
                    CalculadoraPeso.class);

            intent.putExtra("nome", etxNome.getText().toString());
            intent.putExtra("sexoMasculino", rdbSexoMasculino.isChecked());
            startActivity(intent);
        }
    }
}