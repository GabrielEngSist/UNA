package br.com.meupesoideal.interfaces;

import br.com.meupesoideal.dto.ResultadoImc;

public interface ICalculadoraImc {
    ResultadoImc calcularImc();
}