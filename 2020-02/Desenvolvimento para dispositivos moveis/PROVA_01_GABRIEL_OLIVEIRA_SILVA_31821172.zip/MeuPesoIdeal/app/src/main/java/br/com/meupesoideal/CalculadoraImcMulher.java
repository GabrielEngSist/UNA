package br.com.meupesoideal;

import br.com.meupesoideal.dto.Pessoa;
import br.com.meupesoideal.dto.ResultadoImc;
import br.com.meupesoideal.enums.Situacao;
import br.com.meupesoideal.interfaces.ICalculadoraImc;

public class CalculadoraImcMulher implements ICalculadoraImc {
    private Pessoa pessoa;
    public CalculadoraImcMulher(Pessoa pessoa){
        this.pessoa = pessoa;
    }
    @Override
    public ResultadoImc calcularImc() {
        float imc = Math.round(pessoa.getPeso() / (float)(Math.pow(pessoa.getAltura(),2)));
        String imagem;
        Situacao situacao;

        if (imc < 19.1) {
            situacao = Situacao.ABAIXO_PESO;
            imagem = "@drawable/mulher_abaixo_peso";
        } else if (imc < 25.8) {
            situacao = Situacao.PESO_NORMAL;
            imagem = "@drawable/mulher_peso_normal";
        } else if (imc < 32.3) {
            situacao = Situacao.ACIMA_PESO;
            imagem = "@drawable/mulher_acima_peso";
        } else {
            situacao = Situacao.OBESO;
            imagem = "@drawable/mulher_obesa";
        }
        return new ResultadoImc(situacao, imagem, imc);
    }
}
