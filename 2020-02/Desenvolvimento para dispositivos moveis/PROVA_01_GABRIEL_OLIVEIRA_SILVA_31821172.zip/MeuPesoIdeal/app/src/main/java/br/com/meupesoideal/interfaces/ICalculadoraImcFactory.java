package br.com.meupesoideal.interfaces;

import br.com.meupesoideal.dto.Pessoa;

public interface ICalculadoraImcFactory {
    ICalculadoraImc getCalculadora(Pessoa pessoa);
}
