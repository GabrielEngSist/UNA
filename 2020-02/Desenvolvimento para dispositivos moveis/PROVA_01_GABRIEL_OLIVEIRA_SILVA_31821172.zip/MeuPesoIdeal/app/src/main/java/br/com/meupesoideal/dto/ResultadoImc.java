package br.com.meupesoideal.dto;

import br.com.meupesoideal.enums.Situacao;

public class ResultadoImc {
    private Situacao situacao;
    private String imagem;
    private float imc;

    public ResultadoImc(Situacao situacao, String imagem, float imc) {
        this.situacao = situacao;
        this.imagem = imagem;
        this.imc = imc;
    }

    public Situacao getSituacao() {
        return situacao;
    }

    public String getImagem() {
        return imagem;
    }

    public float getImc() {
        return imc;
    }
}
