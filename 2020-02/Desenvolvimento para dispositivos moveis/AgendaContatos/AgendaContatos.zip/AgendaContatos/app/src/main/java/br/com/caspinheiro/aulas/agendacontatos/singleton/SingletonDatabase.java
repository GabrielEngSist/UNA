package br.com.caspinheiro.aulas.agendacontatos.singleton;

import android.content.Context;

import androidx.room.Room;
import br.com.caspinheiro.aulas.agendacontatos.util.AppDatabase;

public class SingletonDatabase {

    private static AppDatabase appDatabase = null;

    private SingletonDatabase(){}

    public static AppDatabase getInstance(Context context){
        if( appDatabase == null ){
            appDatabase = Room.databaseBuilder( context,
                AppDatabase.class, "contato.sqlite" ).build();
        }

        return appDatabase;
    }

}
