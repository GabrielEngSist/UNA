package br.com.caspinheiro.aulas.agendacontatos.util;

import androidx.room.Database;
import androidx.room.RoomDatabase;
import br.com.caspinheiro.aulas.agendacontatos.dao.ContatoDAO;
import br.com.caspinheiro.aulas.agendacontatos.model.Contato;

@Database(entities = {Contato.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    public abstract ContatoDAO contatoDAO();
}
